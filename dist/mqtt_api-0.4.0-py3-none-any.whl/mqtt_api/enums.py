from dataclasses import dataclass
from enum import Enum
from typing import Dict


class RedisKeys(str, Enum):
    EVSE_ID_MAPPING = "evse_id_mapping"


class HardwareEventName(str, Enum):
    CONNECTOR_AND_CHARGING = "connector_and_charging"


class ConnectorStatus(str, Enum):
    AVAILABLE = "available"
    OCCUPIED = "occupied"
    FAULTED = "faulted"


class ChargingStatus(str, Enum):
    IDLE = "idle"
    CHARGING = "charging"
    SUSPENDED_EV = "suspended_ev"
    SUSPENDED_EVSE = "suspended_evse"


class MqttCredentials(str, Enum):
    URL = "broker.hivemq.com"
    USERNAME = None
    PASS = None


class Topics(str, Enum):
    SLAC_JOSEV = "slac/josev"
    SLAC_CS = "slac/cs"
    ISO15118_JOSEV = "iso15118/josev"
    ISO15118_CS = "iso15118/cs"
    OCPP_JOSEV = "ocpp/josev"
    OCPP_CS = "ocpp/cs"


class MessageName(str, Enum):
    AUTHORIZATION = "authorization"
    CHARGING_CONTACTOR = "charging_contactor"
    CHARGING_CONTACTOR_STATUS = "charging_contactor_status"
    CP_STATUS = "cp_status"
    CS_METER_VALUES = "cs_meter_values"
    SLAC_STATUS = "slac_status"
    V2G_SETUP_STATUS = "v2g_setup_status"
    DATA_LINK = "data_link"
    STOP_CHARGING = "stop_charging"
    OCPP_CONFIG = "ocpp_config"


class MessageStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class ActionType(str, Enum):
    REQUEST = "request"
    RESPONSE = "response"
    UPDATE = "update"


class SlacStatus(str, Enum):
    MATCHING = "matching"
    FAILED = "failed"


@dataclass
class JOSEVAPIMessage:
    id: int
    name: MessageName
    type: ActionType
    data: Dict
