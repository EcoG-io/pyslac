import json
import logging
import os
from typing import Dict

import jsonschema

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("mqtt_api")

schemas_cache: Dict[str, dict] = {}


def snake_to_pascal_case(name: str):
    res = name.replace("_", " ").title().replace(" ", "")
    return res


def validate_message(message: dict):
    schema_file_name = snake_to_pascal_case(message["name"] + "_" + message["type"])
    real_dir, _ = os.path.split(os.path.realpath(__file__))
    relative_path = f"schemas/{schema_file_name}.json"
    path = os.path.join(real_dir, relative_path)
    logger.debug(f"Trying to open the path: {path}")
    if schema_file_name not in schemas_cache.keys():
        try:
            with open(path, "r", encoding="utf-8") as f:
                schema_data = f.read()
            schema = json.loads(schema_data)
            schemas_cache[schema_file_name] = schema
        except FileNotFoundError:
            logger.error("Cannot find a JSON schema named: %s", schema_file_name)
            return False
    else:
        schema = schemas_cache[schema_file_name]
    try:
        jsonschema.validate(message, schema)
        return True
    except jsonschema.ValidationError as e:
        logger.error(
            "The message %s did not pass validation\
            against the schema",
            message,
        )
        logger.exception(e)
        return False
