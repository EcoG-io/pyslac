import json
import logging
from typing import Any, Dict, List, Optional

import aioredis

from mqtt_api.enums import ChargingStatus, ConnectorStatus, HardwareEventName, RedisKeys

# The INIT_STATE is a dummy state that we set for the start of the Translator
# If we set it as None, it would make the code harder, as in some parts we would
# need to check if the `self.previous_state` is None or not
INIT_STATE = "A0"

logger = logging.getLogger("TRANSLATOR")
logger.setLevel("INFO")


async def get_evse_id_mapping(redis: aioredis.Redis) -> List:
    """Get the EVSE mapping stored in redis.

    Args:
        redis (aioredis): an instance of aioredis

    Raises:
        TypeError: when there isn't an evse_id map available in redis.

    Returns:
        List: a list of dict containing the EVSEs map

        i.e:
            [{"iso15118_id": "DE-SWT-E123456789",
            "ocpp_id": 1,
            "supply_phases": 3,
            "power": {"max_limit_watts": 13000}},
            {"iso15118_id": "DE-SWT-E32123456",
            "ocpp_id": 2,
            "supply_phases": 0,
            "power": {"max_limit_watts": 100000}}]
    """
    try:
        return json.loads(await redis.get(RedisKeys.EVSE_ID_MAPPING))
    except TypeError as e:
        raise TypeError(
            "There is no evse_id_mapping available in redis.Check ocpp_config.",
            e,
        )


class TranslateCpStatus:
    """Translate incoming "cp_status" messages to valid hardware events.

    Usage
        translator = await TranslateCpStatus.create(redis)
        output = await translator.translate_cp_status_to_hw_event(input)

    IMPORTANT!!!!
    TODO: for now this version of the translator does not work with multiple EVSEs.
    Future versions might need to store a list of dicts for keeping the last state of
    each EVSE.

    i.e:
    self.previous_state = [
                        {"evse_id": "DE-SWT-E123456789", "cp_state": "A2"},
                        {"evse_id": "DE-SWT-E32123456", "cp_state": "C1"}
                        ]
    """

    def __init__(self, evse_id_mapping: Optional[List[Dict[str, Any]]]) -> None:
        """Initialize the class.

        Args:
            evse_id_mapping (Optional[List[Dict[str, Any]]]): [description]
        """
        self.previous_state = INIT_STATE
        self.evse_id_mapping = evse_id_mapping

    @classmethod
    async def create(
        cls,
        redis: Optional[aioredis.Redis] = None,
        evse_id_mapping: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional["TranslateCpStatus"]:
        """Return an instance of the class 'TranslateCpStatus'.

        If the evse_id_mapping was not passed as an argument, it will call
        "get_evse_id_mapping" function to get it from Redis.
        Finally "evse_id_mapping" is then passed to the __init__ for the
        instantiation of the class.

        Args:
            redis: a redis instance.
            evse_id_mapping: the evse_id mapping between OCPP and ISO15118.

        Raises:
            AttributeError: if there is not a mapping or redis instance avaible.

        Returns:
            TranslateCpStatus: an instance of this class
        """
        if evse_id_mapping is None and redis is None:
            raise AttributeError(
                "Neither Redis nor an explicit evse id mapping were provided."
            )
        if evse_id_mapping is None:
            evse_id_mapping = await get_evse_id_mapping(redis)

        return cls(evse_id_mapping)

    def translate_cp_status_to_hw_event(  # noqa: WPS212 WPS231
        self, cp_status: dict
    ) -> Optional[Dict]:
        """Translate the CP status.

        Args:
            cp_status: mqtt message containing cp status.
            example:
            {
                "id": 1,
                "name": "cp_status",
                "type": "update",
                "data":{
                    "evse_id": "DE-ASV-12345",
                    "state": "A2",
                    "max_voltage":"",
                    "min_voltage":"",
                    "duty_cycle": 25
                }
            }

        Returns:
            Dict: a dict indicating a hardware event.
            example:
            {
                "name": "connector_and_charging",
                "type": "update",
                "data": {
                            "evse_id": 1,
                            "connector_status": 1,
                            "charging_status":"idle"
                        }
            }

        """
        data = None
        evse_id = None

        name = HardwareEventName.CONNECTOR_AND_CHARGING
        action_type = cp_status["type"]

        cp_status_evse_id = cp_status["data"]["evse_id"]
        cp_status_connector_id = cp_status["data"].get("connector_id", 1)
        current_state = cp_status["data"]["state"]

        if current_state == self.previous_state:
            # CP state didnt change
            return None

        for evse in self.evse_id_mapping:
            if evse.get("iso15118_id") == cp_status_evse_id:
                evse_id = evse.get("ocpp_id")
                break

        if evse_id is None:
            logger.warning(
                "The iso15118_id in cp_status doesn't match any id in the ocpp_config."
                " Translation Aborted."
            )
            return None

        if self.previous_state != INIT_STATE:
            if self.previous_state[0] == current_state[0] and current_state[0] not in {
                "C",
                "D",
            }:
                # A1 <-> A2, won't trigger anything.
                # B1 <-> B2, won't trigger anything.
                return None

        if self.previous_state in {"E", "F"} and current_state[0] in {"C", "D"}:
            # These are impossible transitions and are very unlikely to happen.
            logger.warning(
                f"Transition from {self.previous_state} to {current_state} "
                f"not valid; Translation Aborted."
            )
            return None

        if "A" in current_state:
            data = {
                "evse_id": evse_id,
                "connector_id": cp_status_connector_id,
                "connector_status": ConnectorStatus.AVAILABLE,
                "charging_status": ChargingStatus.IDLE,
            }
            self.previous_state = current_state

        if "B" in current_state:
            data = {
                "evse_id": evse_id,
                "connector_id": cp_status_connector_id,
                "connector_status": ConnectorStatus.OCCUPIED,
            }
            if self.previous_state[0] in {"C", "D"}:
                # from C1/C2 or D1/D2 to -> B
                data.pop("connector_status")
                data["charging_status"] = ChargingStatus.SUSPENDED_EV
            self.previous_state = current_state

        if (
            self.previous_state[0] in {"A", "B"} or self.previous_state in {"C2", "D2"}
        ) and current_state in {"C1", "D1"}:
            # A transition from any state to "C1", "D1" leads to SuspendedEVSE;
            # except a transition between C1 <-> D1
            data = {
                "evse_id": evse_id,
                "connector_id": cp_status_connector_id,
                "charging_status": ChargingStatus.SUSPENDED_EVSE,
            }

            if self.previous_state[0] == "A":
                data["connector_status"] = ConnectorStatus.OCCUPIED

            self.previous_state = current_state

        if (
            self.previous_state[0] in {"A", "B"} or self.previous_state in {"C1", "D1"}
        ) and current_state in {"C2", "D2"}:
            # A transition from any state to "C2", "D2" leads to Charging;
            # except a transition between C2 <-> D2
            data = {
                "evse_id": evse_id,
                "connector_id": cp_status_connector_id,
                "charging_status": ChargingStatus.CHARGING,
            }
            if self.previous_state[0] == "A":
                data["connector_status"] = ConnectorStatus.OCCUPIED

            self.previous_state = current_state

        if current_state[0] in {"E", "F"}:
            # Faulted state
            data = {
                "evse_id": evse_id,
                "connector_status": ConnectorStatus.FAULTED,
                "charging_status": ChargingStatus.IDLE,
            }
            self.previous_state = current_state

        if data is None:
            logger.warning(
                f"Transaction from {self.previous_state} to "
                f"{current_state} not recognized; Translation Aborted"
            )
            return None

        return {"name": name, "type": action_type, "data": data}
